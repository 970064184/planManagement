import {CanActivate} from "@angular/router";

export class LoginGuard implements CanActivate{
  canActivate(){
    let islogin:boolean=false;
    var jwt = localStorage.getItem('id_token');
    console.log(jwt);
    if (jwt &&  jwt!='undefined'){
      islogin=true;
    }
    if(!islogin){
      console.log("用户未登录");
    }
    return islogin;
  }

}
