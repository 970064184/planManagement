import {HomeComponent} from "./home/home.component";
import {RouterModule, Routes} from "@angular/router";
import {ModuleWithProviders} from "@angular/core";
import {LoginComponent} from "./login/login.component";
import {Code404Component} from "./code404/code404.component";
import {LoginGuard} from "./guard/login.guard";

const routes: Routes = [
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'login',component:LoginComponent},
/*  {path:'home',component:HomeComponent,canActivate:[LoginGuard]},*/
  {path:'home',component:HomeComponent},
  {path:'**',component:Code404Component},//如果用户输入url地址不正确，或者输入的地址不存在跳转到指定的路径
];

export const rootRouterModule:ModuleWithProviders=RouterModule.forRoot(routes,{useHash:true});
