import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup} from "@angular/forms";
import {Observable} from "rxjs/Observable";
import {Headers, Http, RequestOptions, RequestOptionsArgs} from "@angular/http";
import 'rxjs/Rx';
import {Router} from "@angular/router";


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  options:RequestOptionsArgs;
  model={
    msg:'',
    code:''
  };

  formModel:FormGroup=new FormGroup({
    userName:new FormControl("admin"),
    password:new FormControl("admin")
  });

  constructor(private http: Http,private router:Router) {
    let headers = new Headers({ 'Content-Type': 'application/json;charset=utf-8' });
    this.options = new RequestOptions({ headers: headers });
  }

  ngOnInit() {
  }

  onSubmit(data) {
    var url = "/api/pmsUser/v1/login";
    this.http.post(url, data ,this.options)
      .map(res => res.json())
      .subscribe((data) =>{
      if (data['code']==200){
        localStorage.setItem('id_token', data['data']['id_token']), console.log(data)
        this.router.navigate(['/home']);
      }
        this.model=data;
      });
  }

}
