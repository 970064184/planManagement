import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {rootRouterModule} from './app.router';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {ReactiveFormsModule} from "@angular/forms";
import {HttpModule} from "@angular/http";
import { HomeComponent } from './home/home.component';
import { Code404Component } from './code404/code404.component';
import {LoginGuard} from "./guard/login.guard";
import { HeaderComponent } from './header/header.component';
import { MainMenuComponent } from './main-menu/main-menu.component';
import { TopMenuComponent } from './top-menu/top-menu.component';
import { ContentComponent } from './content/content.component';
import { BottomMenuComponent } from './bottom-menu/bottom-menu.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    Code404Component,
    HeaderComponent,
    MainMenuComponent,
    TopMenuComponent,
    ContentComponent,
    BottomMenuComponent
  ],
  imports: [
    BrowserModule,ReactiveFormsModule,HttpModule,rootRouterModule
  ],
  providers: [LoginGuard],
  bootstrap: [AppComponent]
})
export class AppModule {
}
